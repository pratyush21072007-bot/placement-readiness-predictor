import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from ml import clean, train

class PipelineChecks(unittest.TestCase):
    def test_cleaning(self):
        d = clean(pd.DataFrame({' x ':[' 2 ','?','2'], 'cat':[' YES ','no',' YES ']}))
        self.assertEqual(len(d), 2)
        self.assertEqual(d['cat'].iloc[0], 'yes')
        self.assertTrue(pd.isna(d['x'].iloc[1]))

    def test_end_to_end(self):
        d = clean(pd.read_csv(Path(__file__).parent/'data/demo_synthetic.csv'))
        r = train(d, 'placement_ready', 'yes', ['cgpa','aptitude_score','projects','internship'])
        self.assertEqual(len(r['comparison']), 2)
        self.assertEqual(sum(map(sum,r['confusion'])), r['test_rows'])
        self.assertFalse(set(r['Xtrain'].index) & set(r['example'].index))
        for v in r['metrics'].values():
            self.assertTrue(0 <= v <= 1)
        example = r['example'].copy()
        example['internship'] = 'unseen-category'
        example['cgpa'] = np.nan
        p = r['pipeline'].predict_proba(example)
        self.assertAlmostEqual(float(p.sum()), 1)

    def test_invalid_target(self):
        d = pd.DataFrame({'x':range(40), 'y':['yes']*40})
        with self.assertRaises(ValueError):
            train(d,'y','yes',['x'])

if __name__ == '__main__':
    unittest.main()
