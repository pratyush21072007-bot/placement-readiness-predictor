"""Small, reproducible binary-classification pipeline shared by CLI and UI."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
from sklearn.inspection import permutation_importance


def clean(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    if df.columns.duplicated().any():
        raise ValueError('Duplicate column names after trimming spaces.')
    for c in df:
        if not pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].map(lambda v: v.strip().lower() if isinstance(v, str) else v)
            df[c] = df[c].replace(['', '?', 'na', 'n/a', 'null', 'none', 'nan'], np.nan)
            converted = pd.to_numeric(df[c], errors='coerce')
            if converted.notna().sum() == df[c].notna().sum():
                df[c] = converted
    return df.replace([np.inf, -np.inf], np.nan).drop_duplicates()


def train(df, target, positive, features):
    df = clean(df)
    if target not in df or not features or target in features:
        raise ValueError('Choose a target and at least one separate input feature.')
    before = len(df)
    df = df.dropna(subset=[target])
    labels = list(df[target].unique())
    if len(labels) != 2 or positive not in labels:
        raise ValueError('Target must contain exactly two labels; choose the positive label.')
    X, y = df[features], (df[target] == positive).astype(int)
    if X.isna().all().any():
        raise ValueError('Remove input columns that contain only missing values.')
    if len(df) < 30 or y.value_counts().min() < 8:
        raise ValueError('Need at least 30 labelled rows and 8 examples of each class.')
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.25, stratify=y, random_state=42)
    numeric = list(X.select_dtypes(include='number').columns)
    categorical = [c for c in features if c not in numeric]
    prep = ColumnTransformer([
        ('num', Pipeline([('fill', SimpleImputer(strategy='median')), ('scale', StandardScaler())]), numeric),
        ('cat', Pipeline([('fill', SimpleImputer(strategy='most_frequent')), ('encode', OneHotEncoder(handle_unknown='ignore'))]), categorical)
    ])
    models = {
        'Logistic regression': LogisticRegression(max_iter=2000, class_weight='balanced', random_state=42),
        'Decision tree': DecisionTreeClassifier(max_depth=4, min_samples_leaf=5, class_weight='balanced', random_state=42)
    }
    cv = StratifiedKFold(n_splits=min(5, int(ytr.value_counts().min())), shuffle=True, random_state=42)
    pipelines, rows = {}, []
    for name, model in models.items():
        pipe = Pipeline([('preprocess', prep), ('model', model)])
        scores = cross_validate(pipe, Xtr, ytr, cv=cv, scoring={'precision':'precision', 'recall':'recall', 'f1':'f1'})
        rows.append({'model':name, **{m:float(scores['test_'+m].mean()) for m in ['precision','recall','f1']}})
        pipelines[name] = pipe
    comparison = pd.DataFrame(rows).sort_values('f1', ascending=False)
    selected = comparison.iloc[0]['model']
    # Select using training CV only. The holdout does not choose the winner.
    pipe = pipelines[selected].fit(Xtr, ytr)
    predictions = pipe.predict(Xte)
    metrics = {'precision':float(precision_score(yte, predictions, zero_division=0)),
               'recall':float(recall_score(yte, predictions, zero_division=0)),
               'f1':float(f1_score(yte, predictions, zero_division=0))}
    importance = permutation_importance(pipe, Xte, yte, scoring='f1', n_repeats=10, random_state=42)
    importance = pd.DataFrame({'feature':features, 'mean_f1_decrease':importance.importances_mean,
                               'std':importance.importances_std}).sort_values('mean_f1_decrease', ascending=False)
    example = Xte.iloc[[0]].copy()
    probability = float(pipe.predict_proba(example)[0, 1])
    return dict(pipeline=pipe, comparison=comparison, selected=selected, metrics=metrics,
                confusion=confusion_matrix(yte, predictions, labels=[0,1]).tolist(), importance=importance,
                example=example, probability=probability, actual=int(yte.iloc[0]),
                features=features, numeric=numeric, Xtrain=Xtr,
                rows=len(df), missing_targets_removed=before-len(df), train_rows=len(Xtr), test_rows=len(Xte))
