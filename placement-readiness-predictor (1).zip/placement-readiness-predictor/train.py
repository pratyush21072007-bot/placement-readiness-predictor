import argparse
import json
from pathlib import Path
import pandas as pd
from ml import clean, train

p = argparse.ArgumentParser(description='Train on a CSV and export reproducible evaluation reports.')
p.add_argument('--data', required=True)
p.add_argument('--target', required=True)
p.add_argument('--positive', required=True, help='Positive label, e.g. yes or 1')
p.add_argument('--features', required=True, help='Comma-separated pre-placement input columns')
p.add_argument('--out', default='reports/official')
a = p.parse_args()
df = clean(pd.read_csv(a.data))
labels = list(df[a.target].dropna().unique())
positive = next((v for v in labels if str(v) == a.positive.strip().lower()), None)
if positive is None:
    p.error(f'Positive label not found. Choose from: {labels}')
r = train(df, a.target, positive, [v.strip() for v in a.features.split(',')])
out = Path(a.out)
out.mkdir(parents=True, exist_ok=True)
r['comparison'].to_csv(out/'model_comparison.csv', index=False)
r['importance'].to_csv(out/'feature_importance.csv', index=False)
summary = {k:r[k] for k in ['selected','metrics','confusion','probability','actual','rows','train_rows','test_rows','missing_targets_removed']}
summary.update(dataset=str(a.data), target=a.target, positive_label=str(positive), features=r['features'], seed=42,
               example=r['example'].to_dict(orient='records')[0])
(out/'evaluation.json').write_text(json.dumps(summary, indent=2, default=str))
print(json.dumps(summary, indent=2, default=str))
