# Placement Readiness Predictor
GDG-USAR AI/ML Project 1. A small binary-classification pipeline with a Streamlit input interface.

## Important: official data is still required
The supplied task PDF describes the project but contains no placement-readiness dataset. `data/demo_synthetic.csv` is generated software-test data, NOT GDG-USAR data. All bundled reports are demo results. Obtain the official CSV from GDG-USAR and rerun before submission. Target names and inputs are deliberately configurable because the official schema is unknown.

## Start on Windows (beginner steps)
1. Extract this ZIP completely: right-click > Extract All. Open the extracted project folder.
2. Install Python 3.11 or 3.12 if needed. Enable the installer option **Add Python to PATH**.
3. Double-click `run_windows.bat`. The first run installs dependencies and needs internet.
4. A browser opens at `http://localhost:8501`. Keep the terminal window open.
5. Enable **Use synthetic demonstration data** to check it works.
6. For official work, upload the GDG CSV, select its target, choose the label meaning ready, and select useful input features. Click **Train and compare models**.
7. Review metrics, feature importance and the example. Enter values under **Try your own input**.

Alternative: in the project folder address bar type `cmd`, press Enter, then:
```bat
py -3 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m streamlit run app.py
```
If Windows reports a DLL blocked by Application Control, save the full error. An application-control policy needs its approved software or administrator resolution; reinstalling packages is not guaranteed to fix it.

## Generate saved reports
In the project folder, run the following demo command:
```bat
.venv\Scripts\python train.py --data data/demo_synthetic.csv --target placement_ready --positive yes --features cgpa,aptitude_score,projects,internship --out reports/demo
```
For official data, replace the file path, target, positive label and feature names with the actual CSV schema; use `--out reports/official`. Outputs: model comparison, feature importance and evaluation JSON containing an example prediction and its actual label. The UI displays results; the CLI saves a report bundle.

## How it works
1. Trim column names; normalize category whitespace/case; convert fully numeric columns; mark common missing tokens; remove exact duplicate rows; drop rows with missing targets.
2. Define ready as positive class 1. Require two classes and enough rows for stratification.
3. Split 75% training / 25% holdout using seed 42.
4. Inside each training fold only, fill numeric gaps with the median and categorical gaps with the mode. Scale numbers and one-hot encode categories, allowing unknown categories at prediction time.
5. Compare balanced logistic regression and a depth-4 decision tree using up to five stratified training folds. Select using mean F1. Hyperparameters are fixed before seeing the holdout.
6. Fit the selected model on the training portion and report holdout precision, recall, F1 and a confusion matrix.
7. Show permutation importance: holdout F1 reduction when each feature is shuffled. Do not use these holdout results to repeatedly tune the model; a new final test set would then be needed.

Precision measures correctness among ready predictions. Recall measures coverage of truly ready students. F1 balances these two. Positive labels and class counts matter when interpreting scores. Small datasets may produce unstable estimates.

## Feature reasoning and data checks
For the demo, CGPA measures academic performance, aptitude score measures assessment performance, projects indicate practical experience, and internship indicates exposure to work. These are plausible inputs, not proven causes of placement. For the official CSV, document why each selected input is available BEFORE the outcome. Exclude student IDs/names/contact details and outcome-derived values such as salary, offer letter or placed status when those reveal the target. Review impossible values against the official data dictionary instead of guessing valid ranges. Mixed numeric units or malformed numbers require explicit dataset-specific correction. Do not use this tool for real hiring decisions.

If a student appears in several rows, perform a group-based split by student before evaluation; the current pipeline assumes one independent record per student. Rename semantically equivalent target labels in the source CSV if needed. Unknown labels are not silently guessed.

## Example interpretation
`reports/demo/evaluation.json` stores one held-out student's inputs, predicted probability and actual label. A probability at least 0.5 produces class 1 (ready); below 0.5 produces class 0. The model uses learned input relationships after preprocessing. Probabilities are uncalibrated estimates; global feature importance does not explain the exact contribution to a specific student's prediction.

## Files
- `app.py`: CSV upload, training interface, metrics, feature importance and prediction form.
- `ml.py`: shared cleaning, preprocessing, model comparison and evaluation.
- `train.py`: command-line report export.
- `data/demo_synthetic.csv`: synthetic test fixture.
- `reports/demo/`: reproducible software-test results only.
- `DECISIONS.md`: design changes and limitations.
- `AI_USAGE.md`: transparent AI assistance disclosure.
- `tests.py`: pipeline validation checks.

## Upload to GitHub using the website
1. Sign in to GitHub. Click **+ > New repository**.
2. Name it `placement-readiness-predictor`; choose the visibility required by GDG.
3. Click **Create repository**, then **uploading an existing file** (or **Add file > Upload files**).
4. Upload the project contents with their folders, not just the ZIP. Do not upload `.venv`, `__pycache__`, credentials or private student data. Browser uploads do not apply `.gitignore` automatically.
5. Commit with message `Build placement readiness classification pipeline`.
6. Verify README, Python files, requirements, DECISIONS and AI_USAGE appear. Add official evaluation reports after rerunning on the supplied dataset.
7. Submit the repository URL as instructed by GDG. Upload the official dataset only if GDG permits redistribution.

## Explain during evaluation
Be able to explain input vs target, one-hot encoding, training-only imputation, train/test split, why two models are compared, precision/recall/F1, data leakage and the model's limitations. Rewrite the decision notes in your own words after your actual experiments. This project is a scaffold until official dataset validation is completed.
