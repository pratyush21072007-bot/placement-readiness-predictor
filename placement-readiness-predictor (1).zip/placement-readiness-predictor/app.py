import io
from pathlib import Path
import pandas as pd
import streamlit as st
from ml import clean, train

st.set_page_config(page_title='Placement Readiness Predictor', page_icon='🎓', layout='wide')
st.title('🎓 Placement Readiness Predictor')
st.caption('GDG-USAR · AI/ML Project 1 · Logistic regression vs decision tree')
upload = st.file_uploader('Upload the official GDG-USAR dataset (CSV)', type='csv')
demo = st.checkbox('Use synthetic demonstration data', value=False)
if upload is None and not demo:
    st.info('Upload your dataset to begin, or enable demonstration mode to try the project.')
    st.stop()
if upload is not None:
    raw = upload.getvalue()
    source = upload.name
else:
    raw = (Path(__file__).parent/'data/demo_synthetic.csv').read_bytes()
    source = 'SYNTHETIC DEMO — not GDG-USAR data'
    st.warning('Demo metrics are only a software test. Do not submit them as official dataset results.')
try:
    df = clean(pd.read_csv(io.BytesIO(raw)))
except Exception as e:
    st.error(f'Cannot read CSV: {e}')
    st.stop()
st.write('Dataset:', source)
st.dataframe(df.head(), hide_index=True)
target = st.selectbox('Binary target column', df.columns, index=list(df.columns).index('placement_ready') if 'placement_ready' in df else 0)
labels = list(df[target].dropna().unique())
if len(labels) != 2:
    st.error('This target must have exactly two non-missing labels. Select another column.')
    st.stop()
positive = st.selectbox('Which label means placement-ready?', labels, index=labels.index('yes') if 'yes' in labels else 0)
available = [c for c in df if c != target]
defaults = [c for c in available if not any(x in c.lower() for x in ['id', 'name', 'email', 'salary', 'placed', 'offer'])]
features = st.multiselect('Input features — exclude identities and information known only after placement', available, default=defaults)
st.caption('Review feature meaning yourself. For repeated records per student, use a student-level split before submission.')
key = (raw, target, str(positive), tuple(features))
if st.button('Train and compare models', type='primary'):
    try:
        with st.spinner('Cleaning, validating and comparing models…'):
            st.session_state.result = train(df, target, positive, features)
            st.session_state.training_key = key
    except Exception as e:
        st.error(str(e))
        st.stop()
if st.session_state.get('training_key') != key:
    st.stop()
r = st.session_state.result
st.success(f"Selected: {r['selected']} · {r['train_rows']} training rows · {r['test_rows']} holdout rows")
st.subheader('Model comparison (training cross-validation)')
st.dataframe(r['comparison'].round(3), hide_index=True)
st.subheader('Selected model: unseen holdout performance')
cols = st.columns(3)
for col, metric in zip(cols, ['precision', 'recall', 'f1']):
    col.metric(metric.title(), f"{r['metrics'][metric]:.3f}")
st.caption('Precision: how often ready predictions are correct. Recall: how many ready students are found. F1 balances both.')
st.write('Confusion matrix — rows actual, columns predicted; 0 = other label, 1 = ready')
st.dataframe(pd.DataFrame(r['confusion'], index=['Actual 0','Actual 1'], columns=['Predicted 0','Predicted 1']))
st.subheader('Feature importance')
st.bar_chart(r['importance'].set_index('feature')['mean_f1_decrease'])
st.caption('Decrease in holdout F1 after shuffling one input. Negative or near-zero values mean weak evidence of usefulness; this is not causation.')
st.subheader('Example prediction')
st.dataframe(r['example'], hide_index=True)
st.write(f"Ready probability estimate: {r['probability']:.1%}. Prediction: {'ready' if r['probability'] >= .5 else 'not ready'}; actual class: {r['actual']}.")
st.caption('The pipeline imputes missing values, scales numbers, encodes categories, then applies the selected classifier at threshold 0.5. Probabilities are uncalibrated estimates, not placement guarantees.')
st.subheader('Try your own input')
with st.form('prediction'):
    inputs = {}
    for f in r['features']:
        if f in r['numeric']:
            inputs[f] = st.number_input(f, value=float(r['Xtrain'][f].median()))
        else:
            inputs[f] = st.selectbox(f, sorted(r['Xtrain'][f].dropna().unique(), key=str))
    submit = st.form_submit_button('Predict readiness')
if submit:
    p = float(r['pipeline'].predict_proba(pd.DataFrame([inputs]))[0,1])
    st.info(f"{'Ready' if p >= .5 else 'Not ready'} · estimated ready probability {p:.1%}")
st.download_button('Download model comparison CSV', r['comparison'].to_csv(index=False), 'model_comparison.csv', 'text/csv')
