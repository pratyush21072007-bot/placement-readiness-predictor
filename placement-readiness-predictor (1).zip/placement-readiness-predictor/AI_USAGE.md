# AI usage
ChatGPT/Codex assisted with interpreting the task PDF, creating Python code, generating synthetic software-test data, writing documentation, and validating the pipeline.

The official GDG-USAR dataset was not supplied with the PDF. AI-generated demo data and its results are explicitly labelled and must not be presented as official dataset experiments.

Before submitting, I must run the project on the provided CSV, verify target and feature meaning, inspect results, understand the code, and update DECISIONS.md with my own observations. Add any further AI tools or prompts actually used. This disclosure does not claim I independently authored the generated code.
