# Decisions and meaningful changes

## Changed approach: avoid choosing the winner using test scores
An initial simple design would compare both models on the same test set and choose the higher test F1. We rejected that design because using the test labels to choose the model biases the final evaluation. The implemented design selects using stratified cross-validation inside the training split, then evaluates only the selected model on the untouched holdout. This is a design change, not a claim of a measured failed experiment.

## Put preprocessing inside the pipeline
Global imputation before splitting would leak statistics from evaluation rows. Medians, modes, scaling and categorical vocabulary are fitted separately inside training folds. Deterministic whitespace/case normalization and exact-duplicate removal happen before splitting.

## Two small, explainable models
Logistic regression is a linear baseline. A shallow decision tree can model thresholds and interactions. Fixed depth and minimum leaf size limit tree complexity. Balanced class weights address unequal label counts, but do not replace precision/recall evaluation. F1 is the selection metric because both missed ready students and incorrect ready predictions matter.

## Dataset unknown
The PDF includes the requirements but no CSV. A synthetic fixture demonstrates software behavior. Its metrics cannot establish success on the GDG dataset. The interface permits explicit target, positive label and feature selection rather than assuming a schema. Official validity ranges, target definition, repeated-student handling and feature reasoning must be reviewed when that CSV arrives.

## Limitations
No calibration, hyperparameter search or fairness analysis is claimed. Shuffling correlated features can understate importance. The 0.5 decision threshold is fixed. This is an educational readiness estimate, not a placement guarantee.

## Complete after using the official dataset
- Dataset source/version and target meaning:
- Chosen features and why they are available before the outcome:
- Inconsistencies corrected and missing-value counts:
- Actual model comparison and holdout results:
- One error example and likely explanation:
- One change you personally tried and what you learned:
